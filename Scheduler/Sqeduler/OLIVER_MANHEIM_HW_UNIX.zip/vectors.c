#include <stdio.h>
#include "vectors.h"
vector add (vector v1, vector v2)
{
	vector result ;

	result.x = v1.x + v2.x ;
	result.y = v1.y + v2.y ;
	result.z = v1.z + v2.z ;

	return result ;
}

vector sub (vector v1, vector v2)
{
	vector result ;

	result.x = v1.x - v2.x ;
	result.y = v1.y - v2.y ;
	result.z = v1.z - v2.z ;

	return result ;
}


