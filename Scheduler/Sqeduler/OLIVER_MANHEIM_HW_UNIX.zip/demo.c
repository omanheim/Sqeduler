#include <stdio.h>
#include "vectors.h"

int main ()
{
	vector v1,v2,v3,v4;

	v1.x = 1 ;
	v1.y = 2;
	v1.z = 3;
	v2.x = 4;
	v2.y = 5;
	v2.z = 6;
	
	v3 = add(v1,v2) ;
	v4 = sub(v1,v2) ;

	printf ("vector v1 = <%f,%f,%f>\n", v1.x, v1.y, v1.z); 
	printf ("vector v2 = <%f,%f,%f>\n", v2.x, v2.y, v2.z); 
	printf ("sum of   v1 and v2 = <%f,%f,%f>\n", v3.x, v3.y, v3.z); 
	printf ("dif btwn v1 and v2 = <%f,%f,%f>\n", v4.x, v4.y, v4.z); 

}

