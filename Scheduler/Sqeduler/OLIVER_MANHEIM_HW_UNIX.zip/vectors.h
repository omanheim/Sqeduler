#include <stdio.h>

typedef struct
{
	float x ; 
	float y ;
	float z ;

} vector ;

vector add (vector v1, vector v2) ;
vector sub (vector v1, vector v2) ;
